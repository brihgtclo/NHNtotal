package practice.GeometryTest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import practice.Geometry.*;
import practice.Geometry.Square;

public class cubeSurfaceAreaTest {
    @Test
    @DisplayName("정사각형오류 테스트")
    static void squareErrorTest(){
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Square(1,2));
    }

    @Test
    @DisplayName("")
}
