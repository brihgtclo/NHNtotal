package practice.Geometry;

public interface Nemo {
    double getWidth();
    double getHeight();
}
